"""
BizComply FastAPI Application Package
"""

__version__ = "1.0.0"
